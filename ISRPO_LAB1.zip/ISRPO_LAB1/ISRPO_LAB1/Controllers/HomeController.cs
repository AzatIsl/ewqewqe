﻿using ISRPO_LAB1.Model;
using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ISRPO_LAB1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HomeController : Controller
    {
        private MoviesContext? _db;
        public HomeController(MoviesContext appDBContext)
        {
            _db = appDBContext;
        }
        [HttpGet]
        [Route("/getFilm")]
        public async Task<ActionResult<IEnumerable<TableFilm>>> Get()
        {
            return await _db.TableFilms.ToListAsync();
        }
        [HttpGet("{id}")]
        public async Task<ActionResult<TableFilm>> Get(int id)
        {
            var film = await _db.TableFilms.FindAsync(id);

            if (film == null)
            {
                return NotFound();
            }

            return film;
        }
        [HttpPost]
        [Route("/addFilm/{director}/{name}/{description}")]
        public async Task<ActionResult<TableFilm>> Post(string director, string name, string description)
        {
            TableFilm film = new TableFilm();
            film.Director = director;
            film.Name = name;
            film.Description = description;

            await _db.TableFilms.AddAsync(film);
            await _db.SaveChangesAsync();

            return Ok(film);
        }
        [HttpPut]
        [Route("/updateFilm/{id}")]
        public async Task<IActionResult> Put(int id, string director, string name, string description)
        {

            var contactId = await _db.TableFilms.FindAsync(id);
            contactId.Director = director;
            contactId.Name = name;
            contactId.Description = description; ;

            _db.TableFilms.Update(contactId);
            await _db.SaveChangesAsync();

            return Ok(contactId);
        }
        [HttpDelete("/deleteFilm/{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var book = await _db.TableFilms.FindAsync(id);

            if (book == null)
            {
                return NotFound();
            }

            _db.TableFilms.Remove(book);
            await _db.SaveChangesAsync();

            return NoContent();
        }

        private bool FilmExists(int id)
        {
            return _db.TableFilms.Any(b => b.Id == id);
        }
    }
}